package com.example.exampromjulenortizdezarate;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity implements com.example.exampromjulenortizdezarate.Login.OnDialogoConfirmacionListener{
    static String nombre, password;
    public com.example.exampromjulenortizdezarate.Login login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = getSupportFragmentManager();

        login = new com.example.exampromjulenortizdezarate.Login();
        login.show(fm, "login");

    }
    public boolean comprobar()
    {
        nombre = login.getCampoNombre().getText().toString();
        password = login.getCampoPassword().getText().toString();
        if(nombre.equals("usuario1") && password.equals("123456")){
            Toast.makeText(getApplicationContext(),"Bienvenido de vuelta " + nombre ,Toast.LENGTH_SHORT).show();
            return true;
        }
        else
        {
            Toast.makeText(getApplicationContext(),"El usuario no es correcto",Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    @Override
    public void onPossitiveButtonClick() {
        comprobar();
    }

    public void salir(View v)
    {
        System.exit(0);
    }
}
